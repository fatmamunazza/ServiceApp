package com.example.serviceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

public class Recharge extends AppCompatActivity {

    EditText amount;
    ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recharge);

        amount=findViewById(R.id.amount);
        back=findViewById(R.id.back);

        amount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                amount.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_money,0,0,0);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    amount.setBackground(getDrawable(R.drawable.edittext_select));
                }
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              finish();
              overridePendingTransition(R.anim.no_animation,R.anim.slide_out_bottom);

            }
        });
    }
}
